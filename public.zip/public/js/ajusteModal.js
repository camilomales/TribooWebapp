$(document).ready(function(){
    var ancho = $(window).width();
    if(ancho>778){
        $('.modal-dialog').css('margin-left', '-250px');
    } 
});