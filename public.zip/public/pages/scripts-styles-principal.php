<link rel="shortcut icon" href="images/favicon.png">

<!-- Bootstrap CSS -->    
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- bootstrap theme 
<link href="css/bootstrap-theme.css" rel="stylesheet">-->
<!--external css-->
<!-- font icon -->
<link href="css/elegant-icons-style.css" rel="stylesheet" />

<link href="css/style2.css" rel="stylesheet">
<link href="css/estilostriboo.css" rel="stylesheet">
<!--<link href="css/style-responsive3.css" rel="stylesheet" />-->
<link rel="stylesheet" type="text/css" href="css/daterangepicker.css" />
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
<script src="js/jquery.js"></script>
<script src="js/jquery-ui.min.js"></script>

<script src="js/anuncio.js"></script>
<script src="js/editarPerfil.js"></script>
<script src="js/tusIntereses.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- nice scroll -->
<script src="js/jquery.scrollTo.min.js"></script>
<script src="js/jquery.nicescroll.js" type="text/javascript"></script>


<!--custome script for all page-->
<script src="js/scripts.js"></script>
<!-- custom script for this page-->
<script src="js/aprovecharPromociones.js"></script>
<script src="js/jquery.validate.js"></script>
<script src="js/jquery-rating.js"></script>
<script src="js/bootstrapValidator.min.js"></script>
<script src="js/validacionesFormInteraccion.js"></script>
<!--<script src="js/ajusteModal.js"></script>-->
<script src="assets/inputmask/jquery.inputmask.bundle.js"></script>
<script type="text/javascript" src="js/moment.min.js"></script>
<script type="text/javascript" src="js/daterangepicker.js"></script>
