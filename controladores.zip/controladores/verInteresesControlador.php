<?php
require_once "../modelos/interesesModelo.php";
$interesModelo = new interesesModelo();

/*
$int = $interesModelo->listarInteresesUsuario($_SESSION['sesion']);
$contar = count($int);

foreach($int as $fila):
	for($i=0; $i<$contar; $i++){
		$array[$i]=array($fila['idCategoria']);
	}
	
endforeach;

*/
?>