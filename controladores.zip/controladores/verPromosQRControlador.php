<?php  
 require_once "../modelos/promosQRModelo.php";

 $promosModel = new promosQRModelo();
 $idsPromos= $promosModel->verIdPromo('');
?>